package ca.qc.bdeb.prog3.tp2a18.vue;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente les ennemis en ligne de 6.
 * @author 1737787
 */

public class Ennemi1 extends Ennemi implements Collisionable,Bougeable{
    
    private static final int DELAI = 5;
    private int animation = 0;
    private int delaiInput;
    private ArrayList<Image> listeAnimation = new ArrayList<>();
    private final static int DEPLACEMENT_X = 6;

    /**
     * Constructeur de l'ennemi 1.
     * @param x La position en x de l'ennemi à sa création.
     * @param y La position en y de l'ennemi à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images de
     * l'ennemi.
     */
    public Ennemi1(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 0, 2);
        listeAnimation.add(spriteSheet.getSubImage(2, 2));
        listeAnimation.add(spriteSheet.getSubImage(3, 2));
    }

    /**
     * Cette méthode fait bouger et animer l'ennemi.
     */
    @Override 
    public void bouger() {
       if (delaiInput == DELAI) {
            this.x = x - DEPLACEMENT_X;
            
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;
        
        if (animation == 0) {
            this.image = listeAnimation.get(0);
        } else if (animation == 150) {
            this.image = listeAnimation.get(1);
        } else if (animation == 300) {
            animation = -1;
        }
        animation++;
    }

  
    
}
