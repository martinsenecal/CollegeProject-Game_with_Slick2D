package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.geom.Rectangle;

/**
 * Cette interface regroupe les objets devant bouger sans intervention du
 * joueur. Elle contient deux méthodes abstraites.
 *
 * @author MGrenon
 */
public interface Bougeable {

    public void bouger();

    public Rectangle getRectangle();
}
