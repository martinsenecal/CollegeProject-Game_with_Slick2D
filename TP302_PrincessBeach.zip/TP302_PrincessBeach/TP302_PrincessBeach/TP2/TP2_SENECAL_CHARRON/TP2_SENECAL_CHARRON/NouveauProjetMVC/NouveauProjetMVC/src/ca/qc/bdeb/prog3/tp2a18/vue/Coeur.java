package ca.qc.bdeb.prog3.tp2a18.vue;

/**
 * Cette classe représente les éléments graphiques associés aux points de vie de
 * la princesse.
 *
 * @author Martin et Nicolas
 */
public class Coeur extends Entite {

    /**
     * Constructeur du coeur.
     *
     * @param x La position en x de l'ennemi à sa création.
     * @param y La position en y de l'ennemi à sa création.
     */
    public Coeur(float x, float y) {
        super(x, y, 28, 28, "images/coeur.png");
    }

}
