package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente l'arrière-plan du jeu.
 *
 * @author Martin et Nicolas
 */
public class Ciel extends Entite {

    /**
     * Constructeur du ciel.
     *
     * @param x La position en x de l'ennemi à sa création.
     * @param y La position en y de l'ennemi à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images de
     * l'ennemi.
     */
    public Ciel(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 12, 12);
    }

}
