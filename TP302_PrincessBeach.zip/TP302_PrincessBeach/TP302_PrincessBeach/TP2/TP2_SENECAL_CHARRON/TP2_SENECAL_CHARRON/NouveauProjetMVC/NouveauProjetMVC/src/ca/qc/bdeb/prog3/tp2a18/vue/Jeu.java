package ca.qc.bdeb.prog3.tp2a18.vue;

import ca.qc.bdeb.prog3.tp2a18.controleur.Controleur;
import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.HAUTEUR;
import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.LARGEUR;
import ca.qc.bdeb.prog3.tp2a18.modele.Modele;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;
import javafx.scene.input.KeyCode;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

/**
 * Le jeu Slick2D, la vue du programme, et ce qui fait fonctionner tout le
 * programme sauf le score et les points de vie.
 *
 * @author NMartin et Nicolas
 */
public class Jeu extends BasicGame implements Observer {

    private Controleur controleur;
    private Modele modele;
    private CopyOnWriteArrayList<Bougeable> listeBougeable = new CopyOnWriteArrayList<>(); // Tout ce qui bouge
    private CopyOnWriteArrayList<Entite> listeEntite = new CopyOnWriteArrayList<>(); // Toutes les entités
    private ArrayList<KeyCode> listeKeys = new ArrayList<>(); // Les touches enfoncées
    private Input input; // L’entrée (souris/touches de clavier, etc.)

    //Toutes les SpriteSheet nécessaires au dessin des composantes graphiques.
    private SpriteSheet spriteSheetMonde64;
    private SpriteSheet spriteSheetMonde32;
    private SpriteSheet spriteSheetPrincesse;
    private SpriteSheet spriteSheetDivers;

    //Random qui sera utilisé un peu partout dans le programme.
    //On peut garder le même random??
    private Random rand = new Random();

    //Instance du personnage principal.
    private Princesse princesse;

    private boolean changerTemps = true; //Boolean qui permet de changer le temps écoulé depuis la fin de la partie.
    private boolean gameOver = false;

    //Décomptes pour divers buts.
    private long tempsDernierProjectile = 1; //Depuis que le dernier projectile a été tiré.
    private long tempsBonusBalles = 1; //Décompte de la durée du bonus pour tirer trois balles.
    private long tempsFinPartie = 1; //Depuis la fin de la partie.

    private String scoreJeu = "0"; //String affichée indiquant en temps réel le score du joueur.

    /**
     * Contructeur de Jeu
     *
     * @param gamename Le nom du jeu
     * @param controleur Le contrôleur du jeu
     * @param modele Le modèle du jeu
     */
    public Jeu(String gamename, Controleur controleur, Modele modele) {
        super(gamename);
        this.modele = modele;
        this.controleur = controleur;
        modele.addObserver(this);
        // …
    }

    /**
     * Initialiser le jeu
     *
     * @param container Le container du jeu
     * @throws SlickException si le jeu plante
     */
    //Parout dans le init, ce qui doit être dessiné sera ajouté à listeEntite et ce qui doit bouger sera ajouté à la listeBougeable.
    public void init(GameContainer container) throws SlickException {
        //Deux SpriteSheet de la même source ayant des dimensions différentes pour utiliser moins d'instances de certaines classes.
        spriteSheetMonde32 = new SpriteSheet("images/sprites_monde.png", 32, 32);
        spriteSheetMonde64 = new SpriteSheet("images/sprites_monde.png", 64, 64);
        spriteSheetPrincesse = new SpriteSheet("images/sprites_princess.png", 32, 64);
        spriteSheetDivers = new SpriteSheet("images/sprites_divers.png", 32, 32);

        //On ajoute le ciel en premier pour qu'ils soit en arrière-plan.
        for (int i = 0; i < LARGEUR / 64; i++) {
            for (int j = 0; j < (HAUTEUR / 64) - 1; j++) {
                listeEntite.add(new Ciel(64 * i, 64 * j, spriteSheetMonde64));
            }
        }

        //On ajoute le reste de l'arrière-plan.
        for (int i = 0; i < (LARGEUR / 32) + 2; i++) {
            Plancher plancher;
            plancher = new Plancher(32 * i, spriteSheetMonde32);

            Gazon gazon;
            gazon = new Gazon(32 * i, spriteSheetMonde32);

            listeBougeable.add(gazon);
            listeBougeable.add(plancher);

            listeEntite.add(gazon);
            listeEntite.add(plancher);
        }

        input = container.getInput();

        //On crée le personnage principal du jeu.
        princesse = new Princesse(spriteSheetPrincesse, false);
        listeEntite.add(princesse);

        //On crée les premiers coeurs indiquant les points de vie.
        listeEntite.add(new Coeur(5, 10));
        listeEntite.add(new Coeur(38, 10));
        listeEntite.add(new Coeur(71, 10));

        creerArbre();
    }

    /**
     * Update du jeu
     *
     * @param container Le container du jeu
     * @param delta N/A
     * @throws SlickException Si le update plante
     */
    public void update(GameContainer container, int delta) throws SlickException {
        if (!modele.isPartieFinie()) { //Si la partie n'est pas finie, on fait tout ce qui suit.
            for (Bougeable b : listeBougeable) {
                b.bouger(); //On fait bouger selon leurs caractéristiques tout ce qui doit être bougé.
            }

            //On anime les fleurs qui tirent des boules de feu.
            for (Entite e : listeEntite) {
                if (e instanceof EnnemiSol) {
                    if (((EnnemiSol) e).getAnimation() == 0) {
                        Feu feu = ((EnnemiSol) e).tirerFeu();
                        listeEntite.add(feu);
                        listeBougeable.add(feu);
                    }
                }
            }

            //Ces deux méthodes vérifient s'il y a un nombre correct d'arbres dans l'écran, puis en créent si nécessaire.
            existeArbre();
            hasardArbres();

            //À chaque trois secondes, on créé un ennemi.
            if (System.currentTimeMillis() % 3000 == 0) {
                creerEnnemis();
            }

            //On vérifie si des entités entrent en collision, et on gère cette collision le cas échéant.
            gestionCollision();

            //On enlève le bonus du tir de trois balles si la princesse l'a depuis plus de 10 secondes.
            if (System.currentTimeMillis() - tempsBonusBalles > 10000) {
                princesse.setIsTroisBalles(false);
            }

            //Si ça fait assez longtemps que la princesse a lancé un boulet que l'utilisateur appuie sur espace, un autre boulet est lancé.
            if (listeKeys.contains(KeyCode.SPACE) && (System.currentTimeMillis() - tempsDernierProjectile) >= 500) {
                Projectile projectile;
                projectile = princesse.creerProjectile();
                listeEntite.add(projectile);
                listeBougeable.add((Bougeable) projectile);

                //Si la princesse a le bonus de trois balles, on appelle les méthodes nécessaires.
                if (princesse.isATroisBalles()) {
                    Projectile projectileHaut;
                    projectileHaut = princesse.creerProjectileHaut();
                    listeEntite.add(projectileHaut);
                    listeBougeable.add((Bougeable) projectileHaut);

                    Projectile projectileBas;
                    projectileBas = princesse.creerProjectileBas();
                    listeEntite.add(projectileBas);
                    listeBougeable.add((Bougeable) projectileBas);

                }
                //On met à jour le temps du dernier projectile tiré.
                tempsDernierProjectile = System.currentTimeMillis();
            }

            //On traite les touches enfoncées par l'utilisateur.
            getKeys();
            traiterKeys();

        } else {
            //Si on peut changer le temps de la fin de la partie, on le fait, puis on empêche de le refaire.
            if (changerTemps) {
                tempsFinPartie = System.currentTimeMillis();
                changerTemps = false;
            }
            gameOver = true; //Affiche la String Game Over.

            //On réinitialise le jeu.
            menageFinPartie();

            //On appelle le contr¸oleur pour indiquer au modèle que la partie est terminée et qu'il faut la recommencer.
            controleur.finPartie();

            //Après trois secondes d'attente, la partie recommence de nouveau.
            if (System.currentTimeMillis() - tempsFinPartie >= 3000) {
                controleur.recommencer();
                changerTemps = true; //On permet à nouveau de changer le temps de la fin de partie, car c'est une nouvelle partie.
                gameOver = false;
            }
        }
    }

    /**
     * Dessiner le jeu
     *
     * @param container Le container du jeu
     * @param g Le graphics du container
     * @throws SlickException Si le render plante
     */
    public void render(GameContainer container, Graphics g) throws SlickException {
        //On dessine toutes les entités de la liste.
        for (Entite e : listeEntite) {
            g.drawImage(e.getImage(), e.getX(), e.getY());
        }

        //On dessine le score du joueur.
        container.getGraphics().drawString(scoreJeu, 5, 50);

        //On affiche GAME OVER si la partie est terminée.
        if (gameOver) {
            String fin = "GAME OVER";
            container.getGraphics().drawString(fin, LARGEUR / 2 - 40, HAUTEUR / 2 - 5);
        }
    }

    /**
     * Cette méthode crée de nouveaux arbres.
     */
    private void creerArbre() {
        //Position de l'objet représentant la princesse dans la liste d'entités.
        int posPrincesseEntite = listeEntite.indexOf(princesse);

        Random r = new Random();
        int nombreTroncs = r.nextInt(8) + 1; //Ce random décide de la hauteur de l'arbre à créer.

        for (int i = 0; i < nombreTroncs; i++) {
            Tronc tronc;
            tronc = new Tronc(LARGEUR, HAUTEUR - 96 - (i * 32), spriteSheetMonde32);
            listeBougeable.add(tronc);
            listeEntite.add(posPrincesseEntite - 1, tronc); //On met les nouveaux troncs avant la princesse dans la liste afin que celle-ci soit devant tous les arbres.
        }

        //On rajoute les feuilles par-dessus le tronc.
        Arbre arbre;
        arbre = new Arbre(LARGEUR, HAUTEUR - 96 - (nombreTroncs * 32), spriteSheetMonde32);
        listeBougeable.add(arbre);
        listeEntite.add(posPrincesseEntite - 1, arbre);
    }

    /**
     * Cette méthode décide au hasard de créer un arbre à une fréquence assez
     * peu fréquente.
     */
    private void hasardArbres() {
        int hasard = rand.nextInt(5000);

        if (hasard == 40 && !existeArbreProche()) { //S'il n'y a pas d'arbres trop proches et que le hasard tombe sur le bon nombre, un nouvel arbre est créé.
            creerArbre();
        }

        if (!existeArbre() && !existeArbreProche()) { //S'il n'y a plus d'arbres dans l'écran, on en crée un sans passer par le random.
            creerArbre();
        }
    }

    /**
     * Cette méthode détermine s'il y a un arbre dans l'écran.
     *
     * @return existeUnArbre True s'il y a un arbre dans l'écran.
     */
    private boolean existeArbre() {
        boolean existeUnArbre;
        float maxX = 0; //Position de l'arbre le plus à droite dans l'écran.

        for (Bougeable b : listeBougeable) {
            if (b instanceof Arbre) {
                float x = ((Arbre) b).getX();
                if (x > maxX) {
                    maxX = x;
                }
            }
        }

        if (maxX > 40) { //Si l'arbre le plus à droite est sur le point de disparaître à gauche, on retourne false pour en créer un.
            existeUnArbre = true;
        } else {
            existeUnArbre = false;
        }
        return existeUnArbre;
    }

    /**
     * Cette méthode détermine s'il y a un arbre trop proche de l'arbre qui
     * serait créé.
     *
     * @return arbreProche True s'il y a un arbre trop proche de l'arbre que
     * l'on créerait.
     */
    private boolean existeArbreProche() {
        boolean arbreProche;
        float maxX = 0;//Position de l'arbre le plus à droite de l'écran.

        //On parcourt tous les arbres pour avoir le plus à droite.
        for (Bougeable b : listeBougeable) {
            if (b instanceof Arbre) {
                float x = ((Arbre) b).getX();
                if (x > maxX) {
                    maxX = x;
                }
            }
        }

        if (maxX > LARGEUR - 32) { //S'il y a un arbre juste à côté de la droite de l'écran, on retourne true pour ne pas créer d'arbre.
            arbreProche = true;
        } else {
            arbreProche = false;
        }
        return arbreProche;
    }

    /**
     * Cette méthde crée des ennemis. Le hasard assigne le type d'ennemi à
     * créer.
     */
    private void creerEnnemis() {
        int hasard = rand.nextInt(4);
        float positionHasard;

        switch (hasard) {
            case 0:
                EnnemiSol ennemiSol1 = new EnnemiSol(LARGEUR + 64, spriteSheetDivers);
                listeBougeable.add(ennemiSol1);
                listeEntite.add(ennemiSol1);
                break;
            case 1:
                positionHasard = rand.nextInt(372); //Hauteur du sol moins hauteur de trois ennemis
                for (int i = 0; i < 6; i++) {
                    Ennemi1 ennemi1 = new Ennemi1(LARGEUR, positionHasard + i * 50, spriteSheetDivers);
                    listeBougeable.add(ennemi1);
                    listeEntite.add(ennemi1);
                }
                break;
            case 2:
                positionHasard = rand.nextInt(500); //Hauteur du sol moins hauteur de trois ennemis et mouvement (approx)
                for (int i = 0; i < 3; i++) {
                    Ennemi2 ennemi2 = new Ennemi2(LARGEUR + i * 32, positionHasard + i * 32, spriteSheetDivers);
                    listeBougeable.add(ennemi2);
                    listeEntite.add(ennemi2);
                }
                break;
            case 3:
                positionHasard = rand.nextInt(576);
                for (int i = 0; i < 4; i++) {
                    Ennemi3 ennemi3 = new Ennemi3(LARGEUR, positionHasard + i * 32, spriteSheetDivers, i + 4);
                    listeBougeable.add(ennemi3);
                    listeEntite.add(ennemi3);
                }
                break;
            default:
                //Pause pour le joueur, même si le jeu est assez facile pour qu'elle ne soit pas nécessaire.
                break;
        }
    }

    /**
     * Cette méthode détruit les objets qui disparaissent de l'écran ou qui ont
     * subi une collision.
     */
    private void enleverEntites() {
        for (Entite e : listeEntite) {
            if (e instanceof Arbre || e instanceof Tronc || e instanceof Feu || e instanceof Projectile || e instanceof Collisionable) {
                if (e.getRectangle().getX() < -40 || e.getRectangle().getY() < -40) { //Le -40 laisse une marge de manoeuvre pour la destruction de l'objet ne paraissent pas.
                    e.setDetruire(true);
                }

            }

            //On enlève l'objet des deux listes pour s'assurer qu'il soit bien détruit.
            if (e.getDetruire()) {
                listeEntite.remove(e);
                if (e instanceof Bougeable) {
                    listeBougeable.remove(e);
                }
            }
        }
    }

    /**
     * Cette méthode vérifie si des entités rentrent en collision, et gère la
     * suite si tel est le cas.
     */
    private void gestionCollision() {
        float x = 0;
        float y = 0;
        boolean drop = false; //Boolean concernant les bonus.

        //On parcourt les listes.
        for (Bougeable b1 : listeBougeable) {
            if (b1 instanceof Collisionable) {
                if (princesse.getRectangle().intersects(b1.getRectangle())) {

                    Entite e1 = (Entite) b1;
                    e1.setDetruire(true); //On indique qu'il faut détruire cette entité.

                    if (b1 instanceof Ennemi || b1 instanceof Feu) {
                        //La princesse perd une vie si elle touche un ennemi ou une boule de feu.
                        controleur.calculPV(false);
                    }

                    if (b1 instanceof Bonus) {
                        controleur.calculScore(false); //On rajoute 25 points si la princesse prend un bonus. Le false indique à la méthode d'ajouter 25 points et non 5.

                        if (b1 instanceof BonusVie) {
                            controleur.calculPV(true); //On ajoute une vie à la princesse si elle prend le champignon 1UP.
                        } else if (b1 instanceof BonusBombe) {
                            int nombreEnnemis = bombe(); //On trouve le nombre d'ennemis pour ajouter au total de points.

                            //On ajoute le nombre de points correspondant au nombre d'ennemis qu'il y avait dans l'écran.
                            for (int i = 0; i < nombreEnnemis; i++) {
                                controleur.calculScore(true);
                            }
                        } else if (b1 instanceof BonusBalle) {
                            //On permet à la princesse de tirer trois balles, et on note le note à partir duquel le bonus est actif.
                            princesse.setIsTroisBalles(true);
                            tempsBonusBalles = System.currentTimeMillis();
                        }
                    }
                }
            }

            for (Bougeable b2 : listeBougeable) {
                if (b2 instanceof Projectile && b1 instanceof Ennemi) {
                    if (b1 != b2) {

                        if (b1.getRectangle().intersects(b2.getRectangle())) {

                            Entite e2 = (Entite) b1;
                            e2.setDetruire(true); //On indique qu'il faut détruire cette entité.

                            x = e2.getX();
                            y = e2.getY();
                            drop = true; //Si le projectile touche un ennemi, on indique qu'il faut créer un bonus.

                            controleur.calculScore(true);
                        }
                    }
                }
            }
        }
        enleverEntites(); //On fait le ménage de l'écran.
        if (drop) {
            hasardBonus(x, y);
        }

    }

    /**
     * Cette méthode calcule le nombre d'ennemis présents dans l'écran.
     *
     * @return nombre Le nombre d'ennemis dans l'écran.
     */
    private int bombe() {
        int nombre = 0;

        for (Bougeable b : listeBougeable) {
            if (b instanceof Ennemi) {
                if (((Ennemi) b).getX() < LARGEUR && ((Ennemi) b).getX() > 0 && ((Ennemi) b).getY() < HAUTEUR && ((Ennemi) b).getY() > 0) {
                    nombre++;
                    ((Ennemi) b).setDetruire(true);
                }
            }
        }

        return nombre;
    }

    /**
     * Cette méthode détermine quel bonus sera donné.
     *
     * @param positionX La position en x de l'ennemi tué où sera mis le bonus.
     * @param positionY La position en y de l'ennemi tué où sera mis le bonus.
     */
    private void hasardBonus(float positionX, float positionY) {
        int hasard = rand.nextInt(10);

        switch (hasard) {
            case 0:
                BonusVie bonusVie = new BonusVie(positionX, positionY, spriteSheetDivers);
                listeEntite.add(bonusVie);
                listeBougeable.add(bonusVie);
                break;
            case 1:
                BonusBombe bonusBombe = new BonusBombe(positionX, positionY, spriteSheetDivers);
                listeEntite.add(bonusBombe);
                listeBougeable.add(bonusBombe);
                break;
            case 2:
                BonusBalle bonusBalle = new BonusBalle(positionX, positionY, spriteSheetDivers);
                listeEntite.add(bonusBalle);
                listeBougeable.add(bonusBalle);
                break;
            default:
                //Ne donne aucun bonus. 5/8 chances d'arriver, pour ne pas avoir un jeu trop facile.
                break;
        }
    }

    /**
     * Cette méthode enlève tous les ennemis, bonus, boules de feu et
     * projectiles à la fin d'une partie, puis remet la princesse à son endroit
     * du début.
     */
    private void menageFinPartie() {
        for (Entite e : listeEntite) {
            if (e instanceof Bonus || e instanceof Ennemi || e instanceof Feu || e instanceof Projectile) {
                e.setDetruire(true);
            }
        }
        enleverEntites();
        princesse.setLocation(10, HAUTEUR - 64 - princesse.height);
    }

    /**
     * Update du patron observateur (MVC)
     *
     * @param o N/A
     * @param arg N/A
     */
    @Override
    public void update(Observable o, Object arg) {
        //On enlève, puis reddesinne les coeurs selon le nombre requis en fonction du nombre de vies qu'a la princesse.
        for (Entite e : listeEntite) {
            if (e instanceof Coeur) {
                listeEntite.remove(e);
            }
        }
        for (int i = 0; i < modele.getPointsVie(); i++) {
            listeEntite.add(new Coeur(33 * i + 5, 10));
        }

        //On affiche le score du joueur.
        scoreJeu = modele.getScore() + "";
    }

    /**
     * Ajoute/enlève les touches de l'ArrayList<KeyCode> listeKeys
     */
    private void getKeys() {
        //Espace
        if (input.isKeyDown(Input.KEY_SPACE)) {
            if (!listeKeys.contains(KeyCode.SPACE)) {
                listeKeys.add(KeyCode.SPACE);
            }
        } else {
            listeKeys.remove(KeyCode.SPACE);
        }

        //Flèche droite
        if (input.isKeyDown(Input.KEY_RIGHT)) {
            if (!listeKeys.contains(KeyCode.RIGHT)) {
                listeKeys.add(KeyCode.RIGHT);
            }
        } else {
            listeKeys.remove(KeyCode.RIGHT);
        }

        //Flèche gauche
        if (input.isKeyDown(Input.KEY_LEFT)) {
            if (!listeKeys.contains(KeyCode.LEFT)) {
                listeKeys.add(KeyCode.LEFT);
            }
        } else {
            listeKeys.remove(KeyCode.LEFT);
        }

        //Flèche haut
        if (input.isKeyDown(Input.KEY_UP)) {
            if (!listeKeys.contains(KeyCode.UP)) {
                listeKeys.add(KeyCode.UP);
            }
        } else {
            listeKeys.remove(KeyCode.UP);
        }

        //Flèche bas
        if (input.isKeyDown(Input.KEY_DOWN)) {
            if (!listeKeys.contains(KeyCode.DOWN)) {
                listeKeys.add(KeyCode.DOWN);
            }
        } else {
            listeKeys.remove(KeyCode.DOWN);
        }

        //W
        if (input.isKeyDown(Input.KEY_W)) {
            if (!listeKeys.contains(KeyCode.W)) {
                listeKeys.add(KeyCode.W);
            }
        } else {
            listeKeys.remove(KeyCode.W);
        }

        //A
        if (input.isKeyDown(Input.KEY_A)) {
            if (!listeKeys.contains(KeyCode.A)) {
                listeKeys.add(KeyCode.A);
            }
        } else {
            listeKeys.remove(KeyCode.A);
        }

        //S
        if (input.isKeyDown(Input.KEY_S)) {
            if (!listeKeys.contains(KeyCode.S)) {
                listeKeys.add(KeyCode.S);
            }
        } else {
            listeKeys.remove(KeyCode.S);
        }

        //D
        if (input.isKeyDown(Input.KEY_D)) {
            if (!listeKeys.contains(KeyCode.D)) {
                listeKeys.add(KeyCode.D);
            }
        } else {
            listeKeys.remove(KeyCode.D);
        }

    }

    /**
     * Cette méthode fait bouger la princesse en fonction du contenu de la
     * listeKeys.
     */
    private void traiterKeys() {

        // Bouger le joueur en fonction des 4 directions
        princesse.bouger(listeKeys); // Bouger le joueur tiendra compte de la liste

    }

    /**
     * Getter de la listeEntite.
     *
     * @return listeEntite La listeEntite.
     */
    public CopyOnWriteArrayList<Entite> getListeEntite() {
        return listeEntite;
    }

}
