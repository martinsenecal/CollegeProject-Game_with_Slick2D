package ca.qc.bdeb.prog3.tp2a18.vue;

/**
 * Cette interface sert seulement à dire ce qui peut affecter la princesse lorsqu'elle les frappe.
 * @author Martin et Nicolas
 */
public interface Collisionable {
    
}
