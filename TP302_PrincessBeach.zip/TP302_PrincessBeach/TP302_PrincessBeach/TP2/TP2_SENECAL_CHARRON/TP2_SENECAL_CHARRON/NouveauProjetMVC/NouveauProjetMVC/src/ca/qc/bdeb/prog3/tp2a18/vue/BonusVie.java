package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente le bonus 1UP.
 *
 * @author Martin et Nicolas
 */
public class BonusVie extends Bonus implements Collisionable, Bougeable {

    /**
     * Constructeur du bonus de vie.
     *
     * @param x La position en x du bonus à sa création.
     * @param y La position en y du bonus à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images du bonus.
     */
    public BonusVie(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 1, 0);
    }

}
