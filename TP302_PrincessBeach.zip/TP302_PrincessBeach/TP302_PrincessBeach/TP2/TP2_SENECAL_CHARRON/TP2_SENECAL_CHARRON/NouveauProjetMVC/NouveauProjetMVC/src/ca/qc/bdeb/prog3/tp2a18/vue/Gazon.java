package ca.qc.bdeb.prog3.tp2a18.vue;

import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.HAUTEUR;
import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.LARGEUR;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente le gazon qui vient au-dessus du sol.
 * @author Martin et Nicolas
 */
public class Gazon extends Entite implements Bougeable{
    
    private int delaiInput;
    private static final int DELAI = 5;
    private static final int DEPLACEMENT_X = 1;
    
    /**
     * Constructeur de gazon.
     * @param x La position en x du bloc de gazon.
     * @param spriteSheet La SpriteSheet où se trouve l'image de gazon.
     */
    public Gazon(float x, SpriteSheet spriteSheet) {
        super(x, HAUTEUR - 64, spriteSheet,3 , 1);
    }

    /**
     * Cette méthode fait bouger le gazon.
     */
    @Override
    public void bouger() { //On met un délai avec un compteur pour ralentir le déplacement.
        if (delaiInput == DELAI) {
            this.x = x - DEPLACEMENT_X;
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;
        
        if(this.x < -32){ //Cette condition remet le plancher à la droite du jeu si celui-ci sort de l'écran par la gauche.
            x = LARGEUR;
        }
    }
    
}
