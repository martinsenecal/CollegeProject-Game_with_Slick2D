package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente une unité de tronc d'arbre.
 *
 * @author Martin et Nicolas
 */
public class Tronc extends Entite implements Bougeable {

    private int animation;
    private static final int DELAI = 5;
    private static final int DEPLACEMENT_X = 1;

    /**
     * Constructeur des troncs.
     *
     * @param x La position en x du tronc.
     * @param y La position en y du tronc.
     * @param spriteSheet est la SpriteSheet contenant les images du tronc.
     */
    public Tronc(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 2, 5);
    }

    /**
     * Cette méthode fait bouger les troncs.
     */
    @Override
    public void bouger() {
        if (animation == DELAI) { //On met un délai avec un compteur pour ralentir le déplacement.
            this.x = x - DEPLACEMENT_X;
        } else if (animation > DELAI) {
            animation = -1; //Si l'animation dépasse le délai voulu, on la remet à zéro.
        }
        animation++;
    }

}
