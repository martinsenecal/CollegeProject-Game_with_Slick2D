package ca.qc.bdeb.prog3.tp2a18.vue;

/**
 * Cette classe représente les boulets que peut tirer la princesse pour éliminer
 * ses ennemis.
 *
 * @author Martin et Nicolas
 */
public class Projectile extends Entite implements Bougeable {

    private int animation;
    private static final int DELAI = 5;
    private int deplacementX;
    private int deplacementY;

    /**
     * Constructeur des projectiles.
     *
     * @param x La position en x du projectile lorsqu'il est lancé.
     * @param y La position en y du projectile lorsqu'il est lancé
     * @param deplacementX La vitesse en x du projectile.
     * @param deplacementY La vitesse en y du projectile.
     */
    public Projectile(float x, float y, int deplacementX, int deplacementY) {
        super(x, y, 16, 16, "images/boulet.png");
        this.deplacementX = deplacementX;
        this.deplacementY = deplacementY; //Le déplacement en x et y des boulets peut être différent, afin d'avoir des trajectoires différentes.
    }

    /**
     * Cette méthode permet de faire bouger les projectiles lancés.
     */
    @Override
    public void bouger() {
        if (animation == DELAI) { //On met un délai avec un compteur pour ralentir le déplacement.
            this.x = x + this.deplacementX;
            this.y = y + this.deplacementY;
        } else if (animation > DELAI) {
            animation = -1;
        }
        animation++;
    }
}
