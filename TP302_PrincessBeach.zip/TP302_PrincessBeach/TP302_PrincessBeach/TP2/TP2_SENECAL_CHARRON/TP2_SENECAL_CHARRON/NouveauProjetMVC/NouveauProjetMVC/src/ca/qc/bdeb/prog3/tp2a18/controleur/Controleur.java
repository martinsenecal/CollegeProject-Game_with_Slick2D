package ca.qc.bdeb.prog3.tp2a18.controleur;

import ca.qc.bdeb.prog3.tp2a18.modele.Modele;
import ca.qc.bdeb.prog3.tp2a18.vue.Jeu;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

/**
 *
 * @author MGrenon
 */
public class Controleur {

    //Dimensions de l'écran de jeu.
    public static final int LARGEUR = 1024, HAUTEUR = 768;

    private Modele modele = new Modele();

    /**
     * Constructeur du contrôleur.
     */
    public Controleur() {

        try {
            AppGameContainer app;
            app = new AppGameContainer(new Jeu("Princess Beach", this, modele));
            app.setDisplayMode(LARGEUR, HAUTEUR, false);
            app.setShowFPS(false);
            app.setVSync(false);
            app.start();
        } catch (SlickException e) {
            e.printStackTrace();
        }

    }

    /**
     * Cette méthode modifie le nombre de vies de la princesse.
     *
     * @param ajouteVie Si true, on ajoute une vie, si false, on enlève une vie.
     */
    public void calculPV(boolean ajouteVie) {
        if (ajouteVie) {
            modele.augmenterPV();
        } else {
            modele.diminuerPV();
        }
    }

    /**
     * Cette méthode calcule le score du joueur.
     *
     * @param estEnnemi Si true, on ajoute 5 points, si false, on ajoute 25
     * points.
     */
    public void calculScore(boolean estEnnemi) {
        if (estEnnemi) {
            modele.augmenterScoreEnnemi();
        } else {
            modele.augmenterScoreBoni();
        }
    }

    /**
     * Cette méthode appelle la méthode finPartie() du modèle.
     */
    public void finPartie() {
        modele.finPartie();
    }

    /**
     * Cette méthode appelle la méthode recommmencer() du modèle.
     *
     */
    public void recommencer() {
        modele.recommencerPartie();
    }

}
