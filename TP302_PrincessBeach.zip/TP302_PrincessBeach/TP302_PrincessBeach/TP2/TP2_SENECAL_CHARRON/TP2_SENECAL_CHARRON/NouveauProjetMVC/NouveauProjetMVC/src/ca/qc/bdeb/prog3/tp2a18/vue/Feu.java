package ca.qc.bdeb.prog3.tp2a18.vue;

import java.util.ArrayList;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente la boule de feu que lance la fleur au sol.
 *
 * @see EnnemiSol
 * @author Martin et Nicolas
 */
public class Feu extends Entite implements Bougeable, Collisionable {

    private static final int DELAI = 5;
    private int animation = 0;
    private int delaiInput;
    private ArrayList<Image> listeAnimation = new ArrayList<>();
    private static final int DEPLACEMENT_X = 1; //La boule de feu doit se déplacer en x pour suivre le reste de l'écran.
    private static final int DEPLACEMENT_Y = 4;

    /**
     * Constructeur de la boule de feu.
     *
     * @param x La position en x de la boule de feu au moment où elle est
     * lancée.
     * @param y La position en y de la boule de feu au moment où elle est
     * lancée.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images de la boule
     * de feu.
     */
    public Feu(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 5, 5);
        listeAnimation.add(spriteSheet.getSubImage(3, 5));
        listeAnimation.add(spriteSheet.getSubImage(4, 5));
        listeAnimation.add(spriteSheet.getSubImage(5, 5));
    }

    /**
     * Cette méthode fait bouger les boules de feu.
     */
    @Override
    public void bouger() {
        if (delaiInput == DELAI) {
            this.y = y - DEPLACEMENT_Y;
            this.x = x - DEPLACEMENT_X;
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;

        //On fait animer les boules de feu pour avoir un mouvement plus réaliste.
        switch (animation) {
            case 0:
                this.image = listeAnimation.get(0);
                break;
            case 40:
                this.image = listeAnimation.get(1);
                break;
            case 80:
                this.image = listeAnimation.get(2);
                break;
            case 120:
                animation = -1;
                break;
            default:
                break;
        }
        animation++;
    }

}
