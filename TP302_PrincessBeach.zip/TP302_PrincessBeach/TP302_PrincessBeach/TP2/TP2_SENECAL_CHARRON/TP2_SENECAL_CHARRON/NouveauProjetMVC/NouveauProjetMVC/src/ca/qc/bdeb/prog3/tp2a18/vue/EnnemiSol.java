package ca.qc.bdeb.prog3.tp2a18.vue;

import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.HAUTEUR;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente les fleurs qui lancent des boules de feu.
 *
 * @see Feu
 * @author Martin et Nicolas
 */
public class EnnemiSol extends Ennemi implements Collisionable, Bougeable {

    private static final int DELAI = 5;
    private int animation = 0;
    private int delaiInput;
    private ArrayList<Image> listeAnimation = new ArrayList<>();
    private SpriteSheet spriteSheet;
    private static final int DEPLACEMENT_X = 1;

    /**
     * Constructeur de la fleur.
     *
     * @param x La position en x de la fleur.
     * @param spriteSheet La SPriteSheet d'où sont tirées les images de la
     * fleur.
     */
    public EnnemiSol(float x, SpriteSheet spriteSheet) {
        super(x, HAUTEUR - 96, spriteSheet, 0, 3);
        listeAnimation.add(spriteSheet.getSubImage(0, 3));
        listeAnimation.add(spriteSheet.getSubImage(1, 3));
        listeAnimation.add(spriteSheet.getSubImage(2, 3));
        this.spriteSheet = spriteSheet;
    }

    /**
     * Cette méthode fait bouger et animer la fleur.
     */
    @Override
    public void bouger() {
        if (delaiInput == DELAI) {
            this.x = x - DEPLACEMENT_X;
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;

        if (animation == 0) {
            this.image = listeAnimation.get(0);
            tirerFeu();
        } else if (animation == 500) {
            this.image = listeAnimation.get(1);
        } else if (animation == 1000) {
            this.image = listeAnimation.get(2);
        } else if (animation == 1500) {
            animation = -1;
        }
        animation++;
    }

    /**
     * Cette méthode lance une boule de feu quand la fleur est ouverte.
     *
     * @return feu La boule de feu à lancer.
     */
    protected Feu tirerFeu() {
        Feu feu;
        feu = new Feu((float) this.x, (float) this.y, spriteSheet);
        return feu;
    }

    /**
     * Getter de l'animation de la fleur.
     *
     * @return animation L'image montrée à un moment précis.
     */
    public int getAnimation() {
        return animation;
    }

}
