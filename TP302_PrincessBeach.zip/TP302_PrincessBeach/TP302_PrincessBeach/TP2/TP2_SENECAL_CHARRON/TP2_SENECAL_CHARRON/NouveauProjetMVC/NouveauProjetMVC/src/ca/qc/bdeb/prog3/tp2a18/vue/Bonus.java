package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe abstraite est héritée par tous les bonus.
 *
 * @author Martin et Nicolas
 */
public abstract class Bonus extends Entite implements Bougeable, Collisionable {

    private int delaiInput;
    private static final int DELAI = 5;
    private static final int DEPLACEMENT_X = 1;

    /**
     * Constructeur de bonus.
     *
     * @param x La position en x du bonus à sa création.
     * @param y La position en y du bonus à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images du bonus.
     * @param ligne La ligne de l'image.
     * @param colonne La colonne de l'image.
     */
    public Bonus(float x, float y, SpriteSheet spriteSheet, int ligne, int colonne) {
        super(x, y, spriteSheet, ligne, colonne);
    }

    /**
     * Cette méthode fait bouger les bonus de la même façon.
     */
    @Override
    public void bouger() {
        if (delaiInput == DELAI) {
            this.x = x - DEPLACEMENT_X;
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;
    }

}
