package ca.qc.bdeb.prog3.tp2a18;

import ca.qc.bdeb.prog3.tp2a18.controleur.Controleur;

/**
 * Le main du programme, il ne fait que lancer le contrôleur.
 * @author MGrenon
 */

/*
Salut, notre auto-évaluation est directement dans le document Word contenant les jeux de tests
Bonne correction :)

*/
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Controleur controleur = new Controleur();
    }

    
}
