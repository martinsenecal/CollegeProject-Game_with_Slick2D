package ca.qc.bdeb.prog3.tp2a18.vue;

import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.HAUTEUR;
import static ca.qc.bdeb.prog3.tp2a18.controleur.Controleur.LARGEUR;
import java.util.ArrayList;
import java.util.Random;
import javafx.scene.input.KeyCode;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente le personnage du jeu.
 *
 * @author 1737787
 */
public class Princesse extends Entite {

    private int deltaX = 2;
    private int deltaY = 2;
    private static final int DELAI = 5;
    private int delaiInput;
    private int animation = 0;
    private ArrayList<Image> listeAnimation = new ArrayList<>(); //Liste pour animer la robe de la princesse.
    private Random random = new Random();
    private boolean fleches; //Boolean indiquant si une touche faisant bouger la princesse est enfoncée.
    private boolean aTroisBalles; //Boolean pour savoir si la princesse peut tirer trois balles à la fois.

    /**
     * Constructeur de la princesse Beach.
     *
     * @param spriteSheet La SpriteSheet d'où sont tirées les images
     * représentant Beach.
     * @param aTroisBalles True si la princesse peut tirer trois projectiles
     * à la fois.
     */
    public Princesse(SpriteSheet spriteSheet, boolean aTroisBalles) {
        super(64, HAUTEUR - 128, spriteSheet, 0, 3);
        listeAnimation.add(spriteSheet.getSubImage(0, 0));
        listeAnimation.add(spriteSheet.getSubImage(1, 0));
        listeAnimation.add(spriteSheet.getSubImage(2, 0));
        listeAnimation.add(spriteSheet.getSubImage(3, 0));
        listeAnimation.add(spriteSheet.getSubImage(4, 0));
        listeAnimation.add(spriteSheet.getSubImage(5, 0));
        this.aTroisBalles = aTroisBalles;
    }

    /**
     * Cette méthode fait bouger Beach en fonction des touches enfoncées.
     *
     * @param listeKeys La liste de toutes les touches enfoncées à un moment
     * précis.
     */
    public void bouger(ArrayList<KeyCode> listeKeys) {
        fleches = (listeKeys.contains(KeyCode.UP) || listeKeys.contains(KeyCode.RIGHT) || listeKeys.contains(KeyCode.LEFT) || listeKeys.contains(KeyCode.DOWN) || listeKeys.contains(KeyCode.W) || listeKeys.contains(KeyCode.S) || listeKeys.contains(KeyCode.A) || listeKeys.contains(KeyCode.D));

        if (delaiInput == DELAI) { //On met un délai avec un compteur pour ralentir le déplacement.
            if (listeKeys.contains(KeyCode.RIGHT) || listeKeys.contains(KeyCode.D)) {
                if (x + deltaX <= LARGEUR - width) {
                    x = x + deltaX;
                }
            }
            if (listeKeys.contains(KeyCode.LEFT) || listeKeys.contains(KeyCode.A)) {
                if (x - deltaX >= 0) {
                    x = x - deltaX;
                }
            }
            if (listeKeys.contains(KeyCode.UP) || listeKeys.contains(KeyCode.W)) {
                if (y - deltaY >= 0) {
                    y = y - deltaY;
                }
            }
            if (listeKeys.contains(KeyCode.DOWN) || listeKeys.contains(KeyCode.S)) {
                if (y + deltaY <= HAUTEUR - height - 64) { //Cette condition empêche la princesse de descendre si elle est déjà au sol.
                    if (y + deltaY > HAUTEUR - 128) { //Cette condition permet d'éviter de faire rentrer la princesse sous le sol.
                        y = HAUTEUR - 128;
                    } else {
                        y = y + deltaY;
                    }
                }
            }

            if (listeKeys.contains(KeyCode.SPACE) && animation % 10 == 0) { //Cette condition ralentit la demande pour créer un projectile afin d'éviter de ralentir le jeu.
                creerProjectile();
                if (aTroisBalles) {
                    creerProjectileBas();
                    creerProjectileHaut();
                }
            }

            if (!fleches && this.y < HAUTEUR - 128 && this.y > 0 && animation % 5 == 0) { //Si aucune touche n'est enfoncée, la princesse flotte.
                int deplacement = random.nextInt(9) - 4;
                y = y + deplacement;
            }
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;

        //On alterne entre différentes robes selon la position en y.
        if (animation == 0 && this.getY() >= HAUTEUR - 128) {
            this.image = listeAnimation.get(3);
        } else if (animation == 100 && this.getY() >= HAUTEUR - 128) {
            this.image = listeAnimation.get(4);
        } else if (animation == 200 && this.getY() >= HAUTEUR - 128) {
            this.image = listeAnimation.get(5);
        } else if (animation == 0 && this.getY() < HAUTEUR - 128) {
            this.image = listeAnimation.get(0);
        } else if (animation == 100 && this.getY() < HAUTEUR - 128) {
            this.image = listeAnimation.get(1);
        } else if (animation == 200 && this.getY() < HAUTEUR - 128) {
            this.image = listeAnimation.get(2);
        } else if (animation == 300) {
            animation = -1;
        }
        animation++;
    }

    /**
     * Cette méthode lance un projectile droit devant.
     *
     * @return projectile est le projectile lancé.
     */
    protected Projectile creerProjectile() {
        Projectile projectile;

        projectile = new Projectile((float) this.x + (width / 2), (float) this.y + (height / 2), 5, 0);

        return projectile;
    }

    /**
     * Cette méthode lance un projectile à 45 degrés vers le haut.
     *
     * @return projectile est le projectile lancé.
     */
    protected Projectile creerProjectileHaut() {
        Projectile projectileHaut;

        projectileHaut = new Projectile((float) this.x + (width / 2), (float) this.y + (height / 2), 3, 3);

        return projectileHaut;
    }

    /**
     * Cette méthode lance un projectile à 45 degrés vers le bas.
     *
     * @return projectile est le projectile lancé.
     */
    protected Projectile creerProjectileBas() {
        Projectile projectileBas;

        projectileBas = new Projectile((float) this.x + (width / 2), (float) this.y + (height / 2), 3, -3);

        return projectileBas;
    }

    /**
     * Setter du boolean troisBalles.
     *
     * @param isTroisBalles La valeur que l'on veut assigner à troisBalles.
     */
    public void setIsTroisBalles(boolean isTroisBalles) {
        this.aTroisBalles = isTroisBalles;
    }

    /**
     * Getter du boolean troisBalles.
     *
     * @return aTroisBalles La valeur actuelle du boolean.
     */
    public boolean isATroisBalles() {
        return aTroisBalles;
    }

}
