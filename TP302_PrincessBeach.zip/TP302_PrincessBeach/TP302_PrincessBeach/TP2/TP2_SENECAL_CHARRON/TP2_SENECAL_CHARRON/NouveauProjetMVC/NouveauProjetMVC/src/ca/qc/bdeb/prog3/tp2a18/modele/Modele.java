package ca.qc.bdeb.prog3.tp2a18.modele;

import java.util.Observable;

/**
 * Modèle du programme. Il gère les points de vie et le score.
 * @author MGrenon
 */
public class Modele extends Observable {
    private int pointsVie = 3;
    private int score = 0;
    private boolean partieFinie = false;
    
    /**
     * Cette classe augmente la vie de la princesse si celle-ci n'en a pas déjà trois.
     */
    public void augmenterPV(){
        if(pointsVie < 3){
            pointsVie += 1;
        }
        majObservers();
    }
    
    /**
     * Cette classe diminue la vie de la princesse et finit la partie si celle-ci tombe à 0.
     */
    public void diminuerPV(){
        pointsVie -= 1;
        if (pointsVie == 0){
            finPartie();
        }
        majObservers();
    }
    
    /**
     * Cette méthode augmente de 5 points le score du joueur.
     */
    public void augmenterScoreEnnemi(){
        score = score + 5;
        majObservers();
    }
    
    /**
     * Cette méthode augmente de 25 points le score du joueur.
     */
    public void augmenterScoreBoni(){
        score = score + 25;
        majObservers();
    }
    
    /**
     * Cette méthode met un boolean à true pour indiquer que la partie est finie.
     */
    
    public void finPartie(){
        if(pointsVie <= 0){
            partieFinie = true;
        }
        majObservers();
        
    }
    
    /**
     * Cette méthode réinitialise les valeurs de certaines variables lorsqu'une nouvelle partie est commencée.
     */
    public void recommencerPartie(){
        pointsVie = 3;
        score = 0;
        partieFinie = false;
        majObservers();
    }
    
    /**
     * Cette méthode envoie à la vue le signal de se mettre à jour.
     */
    public void majObservers(){
        setChanged();
        notifyObservers();
    }

    /**
     * Getter de score.
     * @return score Le score du joueur.
     */
    public int getScore() {
        return score;
    }

    /**
     * Getter de la vie de la princesse.
     * @return pointsVie Le nombre de vies de la princesse.
     */
    public int getPointsVie() {
        return pointsVie;
    }

    /**
     * Getter du boolean indiquant si la partie est finie.
     * @return partieFinie True si la partie est finie.
     */
    public boolean isPartieFinie() {
        return partieFinie;
    }
    
    
    
}
