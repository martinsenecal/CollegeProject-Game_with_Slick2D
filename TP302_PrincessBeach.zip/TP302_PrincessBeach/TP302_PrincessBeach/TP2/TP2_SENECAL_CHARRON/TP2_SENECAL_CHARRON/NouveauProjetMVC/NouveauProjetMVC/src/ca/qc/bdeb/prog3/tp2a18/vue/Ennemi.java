package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe abstraite est héritée par tous les ennmis du jeu.
 *
 * @author Martin et Nicolas
 */
public abstract class Ennemi extends Entite implements Bougeable, Collisionable {

    /**
     * Constructeur d'ennemi.
     *
     * @param x La position en x de l'ennemi à sa création.
     * @param y La position en y de l'ennemi à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images de
     * l'ennemi.
     * @param ligne La ligne de l'image.
     * @param colonne La colonne de l'image.
     */
    public Ennemi(float x, float y, SpriteSheet spriteSheet, int ligne, int colonne) {
        super(x, y, spriteSheet, ligne, colonne);
    }

}
