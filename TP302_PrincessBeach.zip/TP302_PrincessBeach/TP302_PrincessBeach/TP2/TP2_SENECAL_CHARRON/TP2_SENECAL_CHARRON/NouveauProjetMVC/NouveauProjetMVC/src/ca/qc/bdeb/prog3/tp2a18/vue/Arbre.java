/*
 Arbres de taille variable qui apparaissent aléatoirement. Devrait avoir 1-2 arbres dans l’écran à la fois, qui ne se superposent pas.
 */
package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette méthode représente le feuillage des arbres de l'écran.
 *
 * @author Martin et Nicolas
 */
public class Arbre extends Entite implements Bougeable {

    private int animation;
    private static final int DELAI = 5;
    private static final int DEPLACEMENT_X = 1;

    /**
     * Constructeur de l'arbre.
     *
     * @param x La position en x de l'arbre à sa création.
     * @param y La position en y de l'arbre à sa création.
     * @param spriteSheet La SpriteSheet d'où est tirée l'image de l'arbre.
     */
    public Arbre(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 1, 5);
    }

    /**
     * Cette méthode fait bouger les arbres.
     */
    @Override
    public void bouger() {
        if (animation == DELAI) {
            this.x = x - DEPLACEMENT_X;
        } else if (animation > DELAI) {
            animation = -1;
        }
        animation++;
    }

}
