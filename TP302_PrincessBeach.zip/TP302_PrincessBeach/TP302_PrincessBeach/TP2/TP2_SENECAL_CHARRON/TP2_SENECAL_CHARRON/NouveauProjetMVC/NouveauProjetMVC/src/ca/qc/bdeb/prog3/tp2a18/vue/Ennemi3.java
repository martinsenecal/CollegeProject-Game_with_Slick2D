package ca.qc.bdeb.prog3.tp2a18.vue;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente les ennemis en groupe de 4 et ayant une vitesse
 * différente.
 *
 * @author Martin et Nicolas
 */
public class Ennemi3 extends Ennemi implements Collisionable, Bougeable {

    private static final int DELAI = 5;
    private int animation = 0;
    private int delaiInput;
    private ArrayList<Image> listeAnimation = new ArrayList<>();
    private int vitesse;

    /**
     * Constructeur de l'ennemi 3.
     *
     * @param x La position en x de l'ennemi à sa création.
     * @param y La position en y de l'ennemi à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images de
     * l'ennemi.
     * @param vitesse La vitesse d'un des ennemis compris dans le groupe
     * d'ennemis.
     */
    public Ennemi3(float x, float y, SpriteSheet spriteSheet, int vitesse) {
        super(x, y, spriteSheet, 4, 2);
        listeAnimation.add(spriteSheet.getSubImage(4, 2));
        listeAnimation.add(spriteSheet.getSubImage(5, 2));
        listeAnimation.add(spriteSheet.getSubImage(6, 2));
        this.vitesse = vitesse;
    }

    /**
     * Cette méthode fait bouger et animer l'ennemi.
     */
    @Override
    public void bouger() {
        if (delaiInput == DELAI) {

            x = x - vitesse;
        } else if (delaiInput > DELAI) {
            delaiInput = -1;
        }
        delaiInput++;

        if (animation == 0) {
            this.image = listeAnimation.get(0);
        } else if (animation == 100) {
            this.image = listeAnimation.get(1);
        } else if (animation == 200) {
            this.image = listeAnimation.get(2);
        } else if (animation == 300) {
            animation = -1;
        }
        animation++;
    }

}
