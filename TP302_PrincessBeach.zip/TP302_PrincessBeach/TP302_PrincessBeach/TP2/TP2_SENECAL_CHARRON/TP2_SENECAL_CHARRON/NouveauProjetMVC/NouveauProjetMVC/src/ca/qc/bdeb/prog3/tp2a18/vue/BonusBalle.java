package ca.qc.bdeb.prog3.tp2a18.vue;

import org.newdawn.slick.SpriteSheet;

/**
 * Cette classe représente le bonus qui permet de tirer trois projectiles à la
 * fois.
 *
 * @author Martin et Nicolas
 */
public class BonusBalle extends Bonus implements Collisionable, Bougeable {

    /**
     * Constructeur du bonus de balle.
     *
     * @param x La position en x du bonus à sa création.
     * @param y La position en y du bonus à sa création.
     * @param spriteSheet La SpriteSheet d'où sont tirées les images du bonus.
     */
    public BonusBalle(float x, float y, SpriteSheet spriteSheet) {
        super(x, y, spriteSheet, 0, 5);
    }
}
